import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { D3noobCollapsibleTreeComponent } from './d3noob-collapsible-tree/d3noob-collapsible-tree.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, D3noobCollapsibleTreeComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
